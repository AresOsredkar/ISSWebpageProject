<?php
    $a = 15;
    $b = 15;
    if($a>$b){
        echo $a;
    }
    else if($b>$a){
        echo $b;
    }
    else{
        echo $a . " in " . $b;
    }
?>