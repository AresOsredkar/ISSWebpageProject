<?php 
    $a = rand(11,99);
    $b = $a . "";
    $c = $b[1] . $b[0];
    echo $a . " in obrnjeno " . $c;
?>