<?php 
    $a = [1,2,3,4,5,6,7,8,9,10];
    for($i = 0; $i<sizeof($a);$i++){
        echo "Indeks: " . $i . " Vrednost: " . $a[$i] . "<br>";
    }
?>