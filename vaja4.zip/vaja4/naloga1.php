<?php
    $x = "Ares";
    $y = "Osredkar";
    echo "pozdravljeni programer " . $x . " " . $y ."!";
?>