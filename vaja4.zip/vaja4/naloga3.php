<?php
    define("a", 13.9);
    define("b", 13.6);
    define("c", 15.4);
    echo a . "+" . b . "+" . c . "=" . (a+b+c);
?>