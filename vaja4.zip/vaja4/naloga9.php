<!DOCTYPE html>
<html>
    <head>

    </head>
    <body>
<table>
<?php 
    for($i = 1;$i<=10;$i++){
        
        echo $i . "<br>";
    }
?>
</table>
</body>
</html>